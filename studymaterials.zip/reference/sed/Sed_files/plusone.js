window.___jsl=window.___jsl||{};
window.___jsl.h=window.___jsl.h||'r;gc\/23123384-f8bf5791';
window.___gpq=[];
window.gapi=window.gapi||{};
window.gapi.plusone=window.gapi.plusone||(function(){
  function f(n){return function(){window.___gpq.push(n,arguments)}}
  return{go:f('go'),render:f('render')}})();
function __bsld(){var p=window.gapi.plusone=window.googleapisv0.plusone;var f;while(f=window.___gpq.shift()){
  p[f]&&p[f].apply(p,window.___gpq.shift())}
}
window['___jsl'] = window['___jsl'] || {};window['___jsl']['u'] = 'https:\/\/apis.google.com\/js\/plusone.js';window['___jsl']['f'] = ['plusone-unsupported'];(window['___jsl']['ci'] = (window['___jsl']['ci'] || [])).push({});var jsloader=window.jsloader||{};
var gapi=window.gapi||{};
(function(){function g(){return window.___jsl=window.___jsl||{}}function n(a,d,b){b=m(b).join(a);h.length>0&&(b+=d+h.join(a));return b}function m(a){a.sort();for(var d=1;a[d];)a[d]==a[d-1]?a.splice(d,1):++d;return a}function o(a,d){if(a&&d){if(g().c)throw"Cannot continue until a pending callback completes.";g().c=a;g().o=d}}function u(a){if((p||document.readyState)!="loading")return!1;if(typeof window.___gapisync!="undefined")return window.___gapisync;if(a&&(a=a.sync,typeof a!="undefined"))return a;
for(var a=!1,d=document.getElementsByTagName("meta"),b=0,c;c=!a&&d[b];++b)"generator"==c.getAttribute("name")&&"blogger"==c.getAttribute("content")&&(a=!0);return a}function q(a,d){var b;b=a;if(f==="r")b=b.match(v);else{var c=b.match(w);if((b=g().m)&&c){var c=c[2],e=c.lastIndexOf(b);b=(e==0||b.charAt(0)=="."||c.charAt(e-1)==".")&&c.length-b.length==e}else b=!1}if(!b)throw"Cannot load url "+a+".";u(d)?document.write('<script src="'+a+'"><\/script>'):(b=document.createElement("script"),b.setAttribute("src",
a),document.getElementsByTagName("head")[0].appendChild(b))}function r(a,d){f="";h=[];j=window.console||window.opera&&window.opera.postError;k=a;p=d;var b,c=k.match(x)||k.match(y);try{b=c?decodeURIComponent(c[2]):g().h}catch(e){}b&&(b=b.split(";"),f=b.shift(),i=(c=f!=="r")?b.shift():"https://ssl.gstatic.com/webclient/js",l=b.shift(),s=(c=f==="d")&&b.shift()||"gcjs-3p",t=c&&b.shift()||"")}var x=/\?([^&#]*&)*jsh=([^&#]*)/,y=/#([^&]*&)*jsh=([^&]*)/,v=/^https:\/\/ssl.gstatic.com\/webclient\/js(\/[a-zA-Z0-9_\-]+)*\/[a-zA-Z0-9_\-\.:!]+\.js$/,
w=/^(https?:)?\/\/([^/:@]*)(:[0-9]+)?\//,f,i,s,t,l,h,j,k,p;r(document.location.href);jsloader.load=function(a,d){var b;if(!a||a.length==0)j&&j.warn("Cannot load empty features.");else if(f==="d"){var c=a,c=(i[i.length-1]=="/"?i.substring(0,i.length-1):i)+"/"+n(":","!",c);c+=".js?container="+s+"&c=2&jsload=0";l&&(c+="&r="+l);t=="d"&&(c+="&debug=1");b=c}else f==="r"||f==="f"?b=i+"/"+l+"/"+n("__","--",a)+".js":(c="Cannot respond for features ["+a.join(",")+"].",j&&j.warn(c));d=d||{};if(typeof d==="function"){var c=
a,e=d;b?(o(e,1),q(b,void 0),h=m(h.concat(c))):e&&e()}else{(g().cu=g().cu||[]).push(d.config);var e=d.callback,c=a,k=d;b?(o(e,1),q(b,k),h=m(h.concat(c))):e&&e()}};jsloader.reinitialize_=function(a,d){r(a,d)}})();
gapi.load=function(a,b){jsloader.load(a.split(":"),b)};(window.gapi=window.gapi||{}).load=gapi.load;
gapi.load('plusone-unsupported', {'callback': window['__bsld']  });